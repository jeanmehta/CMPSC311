/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bstdemo;

import java.util.Random;


public class BSTDemo {

    
    public static void main(String[] args) {
      Integer[] arr = new Integer[10];  //array to hold generated integers
        CreateArray(arr);        //fill the array
       
        BST myTree = new BST();
       BinaryTreeNode root =myTree.getRoot();
        for (int i = 0; i < arr.length; i++) {
          
            root =myTree.insert(root, arr[i]);
        }
        myTree.inOrder(root);
    
        String [] sArray = {"Hi", "Bye", "Monday", "April", "Donkey"};
        BST yourTree = new BST();
       BinaryTreeNode root2 =yourTree.getRoot();
        for (int i = 0; i < sArray.length; i++) {
            
            root2 =yourTree.insert(root2, sArray[i]);
        }
        yourTree.inOrder(root2);
    }//end main
    
        public static void CreateArray(Integer[] arr)
        { Random generator = new Random();
        for (int j = 0; j < arr.length; j++) {
            arr[j] = generator.nextInt(200);
        }
        }

                
            }
    
    

